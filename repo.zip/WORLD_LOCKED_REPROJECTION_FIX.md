# World-locked reprojection fix

This build fixes a bad fallback behavior introduced by the drop-conceal path.

Previous behavior during drops:

- The shader blended toward `v_uv_fallback`.
- `v_uv_fallback` is a headset-locked fullscreen texture sample.
- During drop/hold periods, the last frame could move with the camera, making latency feel much worse.

New behavior:

- The last successfully uploaded texture remains visible.
- Dropped frames do not clear the screen.
- Dropped/held frames stay world-locked using the last frame's render-view metadata.
- Out-of-bounds reprojection is clamped to the texture edge instead of blending to a camera-locked fullscreen sample or painting black.

Expected result: if the server stalls or drops frames, the last image should feel like a frozen plane/object in space rather than a HUD attached to your head.
