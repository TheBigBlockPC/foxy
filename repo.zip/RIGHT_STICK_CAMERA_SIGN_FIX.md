# Right-stick camera sign fix

This patch leaves the working head-relative left-stick locomotion basis unchanged and flips only the right-stick smooth-turn input.

Previous behavior:

```text
right stick right -> camera turned left
right stick left  -> camera turned right
```

Fixed behavior:

```text
right stick right -> camera turns right
right stick left  -> camera turns left
```

Implementation detail: Quest Browser reports the right-stick X axis with the opposite sign from Foxy hub smooth-turn yaw, so `player_yaw` is updated with `-rx` while movement continues to use the corrected head basis transform.
