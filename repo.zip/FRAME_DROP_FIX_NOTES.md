# Foxy frame-drop fix notes

This build backs out the demand-paced sender that made VR feel like a slideshow.

Important stream changes:

- The PC no longer waits for a displayed-frame ACK before rendering/sending the next frame.
- The Quest keeps at most one pending JPEG while one JPEG is decoding.
- A frame that finishes decoding is no longer discarded just because a newer frame arrived during decode.
- A decoded bitmap is not overwritten while it is waiting for the XR render loop to upload it with `texImage2D`.
- Normal newest-frame drops (`superseded`, `metadata-superseded`, `local-queue-stale`) are not treated as decode errors and do not trigger resync storms.
- Dropping a frame keeps the last successfully uploaded texture visible.

Recommended first run:

```bash
./run.sh --fps 45 --eye-width 960 --eye-height 960 --jpeg-quality 58 --no-desktop \
  --ack-timeout-ms 900 --resync-after-errors 20
```

If that is smooth, raise either resolution or JPEG quality, not both at once.
