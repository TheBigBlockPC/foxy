# Right-stick movement sign fix

The previous head-basis patch used the correct physical head forward/right vectors,
but applied the hub smooth-turn yaw with the same sign used for rendering.

Foxy renders artificial turn by rotating the world with `rotate_y(-player_yaw)`.
Therefore locomotion in hub-world coordinates must apply the inverse sign when
converting head-relative left-stick input into movement. Otherwise, after turning
with the right stick, forward/strafe can feel inverted or rotated away from the
visible camera direction.

This build keeps the right-stick visual turn unchanged and fixes only the movement
basis: `headBasis + inverse smooth-turn yaw -> movement`.
