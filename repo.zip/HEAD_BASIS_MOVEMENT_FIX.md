# Head-basis movement fix

This build fixes the inconsistent head-relative stick direction by avoiding fragile server-side yaw extraction.

Changes:

- Quest Browser computes a flattened heading from the WebXR orientation quaternion.
- Pitch and roll are removed before locomotion, so looking up/down or tilting the head cannot flip the walking direction.
- The server uses flat forward/right XZ vectors directly instead of decoding a matrix into yaw and reconstructing vectors.
- Right/strafe is rebuilt from flattened forward so roll does not affect strafing.
- Existing smooth-turn yaw is applied as a separate 2D rotation.
- `foxy_api.head_basis(state)` is available for custom Python experiences.

Expected behavior:

- Left stick forward follows physical head yaw.
- Looking up/down does not scramble forward direction.
- Head roll does not make strafing diagonal or inverted.
