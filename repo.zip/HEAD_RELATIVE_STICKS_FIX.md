# Head-relative stick movement fix

This build fixes locomotion that ignored physical head rotation.

Changes:

- Browser tracking now sends `viewer.pose` when available.
- Server locomotion computes headset yaw from `viewer.pose`, falling back to the eye view matrix.
- Left-stick movement uses `smooth_turn_yaw + head_yaw`, so pushing forward follows where the user is looking.
- The hub HUD now shows both artificial turn yaw and headset yaw.
- `foxy_api.head_yaw(state)` was added for IPC experiences.
- `examples/opengl_experience.py` now demonstrates head-relative stick movement.

This does not change reprojection; it only fixes the stick locomotion frame of reference.
